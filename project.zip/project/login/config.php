<?php
/*
database configuration assuming you are running mysql using root and password
*/

define('DB_SERVER','localhost:8336');
define('DB_USERNAME','root');
define('DB_PASSWORD', '');
define('DB_NAME','snu_cycle');
$conn = mysqli_connect(DB_SERVER, DB_USERNAME, DB_PASSWORD, DB_NAME);

if($conn == false){
    dir('Error: Cannot connect');
}

?>