<?php
require_once "config.php";
$username = $password = $confirm_password = "";
$username_err = $password_err = $confirm_password_err = "";

if($_SERVER['REQUEST_METHOD']=="POST"){
  //check username is empty
  if(empty(trim($_POST["username"]))){
    $username_err="USername cannot be blank";
  }
  else{
    $sql = "SELECT id FROM users WHERE username = ?";
    $stmt = mysqli_prepare($conn, $sql);
    if($stmt){
      mysqli_stmt_bind_param($stmt, "s",$param_username);
      //set value of param user
      $param_username = trim($_POST['username']);
      //execute
      if(mysqli_stmt_execute($stmt)){
        mysqli_stmt_store_result($stmt);
        if(mysqli_stmt_num_rows($stmt)==1){
          $username_err="This username is already exist";

        }
        else{
          $username = trim($_POST['username']);
        }
      }
      else{
        echo "Something went wrong";
      }
    }
    
  }
  mysqli_stmt_close($stmt);
  
}

// check for password
if(empty(trim($_POST['password']))){
  $password_err = "Password cannot be blank";
}
elseif(strlen(trim($_POST['password']))<5){
  $password_err="passsword cannot be less than 5 characters";
}
else{
  $password=trim($_POST['password']);
}

//check for confirm password
if(trim($_POST['password']) != trim($_POST['confirm_password'])){
  $password_err = "Password doesn't matched";
}
//no error
 if(empty($username_err) && empty($password_err) && empty($confirm_password_err)){
  $sql = "INSERT INTO users (username, password) VALUES (?, ?)";
  $stmt = mysqli_prepare($conn, $sql);
  if($stmt){
    mysqli_stmt_bind_param($stmt, "ss", $param_username,$param_password);

    //set these parameter
    
    $param_username = $username;
    $param_password = password_hash($password, PASSWORD_DEFAULT);

    // execute query
    if(mysqli_stmt_execute($stmt)){
      header("location: login.php");

    }
    else{
      echo "something went wrong... cannot redirect!";
    }

  
  }
  mysqli_stmt_close($stmt);

 }
 mysqli_close($conn);
?>





<!doctype html>
<html lang="en">
  <head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.1.3/dist/css/bootstrap.min.css" integrity="sha384-MCw98/SFnGE8fJT3GXwEOngsV7Zt27NXFoaoApmYm81iuXoPkFOJwJ8ERdknLPMO" crossorigin="anonymous">

    <title>SNU CYCLE login system</title>
  </head>
  <body>
  <nav class="navbar navbar-expand-lg navbar-dark bg-dark">
  <a class="navbar-brand" href="#">SNU CYCLE</a>
  <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarNavAltMarkup" aria-controls="navbarNavAltMarkup" aria-expanded="false" aria-label="Toggle navigation">
    <span class="navbar-toggler-icon"></span>
  </button>
  <div class="collapse navbar-collapse" id="navbarNavAltMarkup">
    <div class="navbar-nav">
      <a class="nav-item nav-link active" href="index.html">Home <span class="sr-only">(current)</span></a>
      <a class="nav-item nav-link" href="#">Services</a>
      <a class="nav-item nav-link" href="#">Featured Vehicles</a>
      <a class="nav-item nav-link disabled" href="#">Contact</a>
    </div>
  </div>
</nav>
<h1>Please Register Here:</h1>
<hr>
<div class=container mt=4>

<form action="" method="post">
  <div class="form-row">
    <div class="form-group col-md-6">
      <label for="inputEmail4">Username</label>
      <input type="text" name="username" class="form-control" id="inputEmail4" placeholder="User Name">
    </div>
    <div class="form-group col-md-6">
      <label for="inputPassword4">Password</label>
      <input type="password" class="form-control" name="password" id="inputPassword4" placeholder="Password">
    </div>
  </div>
  <div class="form-group">
    <label for="inputAddress">Confirm Password</label>
    <input type="text" class="form-control" name="confirm_password" id="inputAddress" placeholder="Confirm Password">
  </div>
  <div class="form-group">
    <label for="firstname">First Name</label>
    <input type="text" class="form-control" name="firstname" id="inputAddress2" placeholder="enter your firstname">
  </div>
  <div class="form-group">
    <label for="lastname">Last Name</label>
    <input type="text" class="form-control" name="lastname" id="inputAddress2" placeholder="enter your lastname">
  </div>

  <div class="form-group col-md-4">
      <label for="gender">Gender</label>
      <select id="gender" name="gender" class="form-control">
        <option selected>Choose...</option>
        <option>Male</option>
        <option>Female</option>
        <option>Others</option>
        </select>
    </div>
    <div class="form-group">
    <label for="Primary phone number">Primary Phone Number</label>
    <input type="number" name="p_phonenumber" class="form-control" id="inputAddress2" placeholder="enter your primary phone number">
  </div>
  <div class="form-group">
    <label for="Secondary phone number">Secondary Phone Number</label>
    <input type="number" name="s_phonenumber" class="form-control"  id="inputAddress2" placeholder="enter your secondary phone number">
  </div>
  <div class="form-group">
    <label for="Primary email_id">Email Address</label>
    <input type="email" name="p_phonenumber" class="form-control" name="emailid" id="inputAddress2" placeholder="enter your email address">
  </div>

  <div class="form-row">
    <div class="form-group col-md-6">
      <label for="inputCity">City</label>
      <input type="text" class="form-control" id="inputCity">
    </div>
    <div class="form-group col-md-4">
      <label for="inputState">State</label>
      <select id="inputState" class="form-control">
        <option selected>Choose...</option>
        <option>Andhra Pradesh</option>
        <option>Arunachal Pradesh</option>
        <option>Assam</option>
        <option>Bihar</option>
        <option>Chhattisgarh</option>
        <option>Goa</option>
        <option>Gujrat</option>
        <option>Haryana</option>
        <option>Himachal Pradesh</option>
        <option>Jharkhand</option>
        <option>Karnataka</option>
        <option>Kerala</option>
        <option>Madhya Pradesh</option>
        <option>Maharashtra</option>
        <option>Manipur</option>
        <option>Meghalaya</option>
        <option>Mizoram</option>
        <option>Nagaland</option>
        <option>Odisha</option>
        <option>Punjab</option>
        <option>Rajasthan</option>
        <option>Sikkim</option>
        <option>Tamil Nadu</option>
        <option>Telangana</option>
        <option>Tripura</option>
        <option>Uttarkhand</option>
        <option>Uttar Pradesh</option>
        <option>West Bengal</option>
        <optin>Andaman and Nicobar Islands</option>
        <optin>Chandigarh</option>
        <optin>Dadra and Nagar Haveli and Daman & Diu</option>
        <optin>Delhi</option>
        <optin>Jammu & kashmir</option>
        <option>Ladakh</optin>
        <option>Lakshadweep</option>
        <option>Puducherry</option>
      </select>
    </div>
    <div class="form-group col-md-2">
      <label for="inputZip">Zip</label>
      <input type="number" class="form-control" id="inputZip">
    </div>
  </div>
  <div class="form-group">
    <div class="form-check">
      <input class="form-check-input" type="checkbox" id="gridCheck">
      <label class="form-check-label" for="gridCheck">
        Check me out
      </label>
    </div>
  </div>
  <button type="submit" class="btn btn-primary">Sign in</button>
</form>
</div>
    <!-- Optional JavaScript -->
    <!-- jQuery first, then Popper.js, then Bootstrap JS -->
    <script src="https://code.jquery.com/jquery-3.3.1.slim.min.js" integrity="sha384-q8i/X+965DzO0rT7abK41JStQIAqVgRVzpbzo5smXKp4YfRvH+8abtTE1Pi6jizo" crossorigin="anonymous"></script>
    <script src="https://cdn.jsdelivr.net/npm/popper.js@1.14.3/dist/umd/popper.min.js" integrity="sha384-ZMP7rVo3mIykV+2+9J3UJ46jBk0WLaUAdn689aCwoqbBJiSnjAK/l8WvCWPIPm49" crossorigin="anonymous"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@4.1.3/dist/js/bootstrap.min.js" integrity="sha384-ChfqqxuZUCnJSK3+MXmPNIyE6ZbWh2IMqE241rYiqJxyMiZ6OW/JmZQ5stwEULTy" crossorigin="anonymous"></script>
  </body>
</html>